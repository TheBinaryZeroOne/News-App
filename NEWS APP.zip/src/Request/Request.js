const API_KEY = "328355ffdfcc4fbdbe8d101187aebf1f"
export const HeadLines = `https://newsapi.org/v2/top-headlines?country=in&apiKey=`
export const newsArticles =(type)=> `https://newsapi.org/v2/everything?q=${type}&apiKey=`

export default API_KEY